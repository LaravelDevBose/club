<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: Arup
 * Date: 12/11/2018
 * Time: 5:29 PM
 */

class MY_Controller extends CI_Controller
{

}
