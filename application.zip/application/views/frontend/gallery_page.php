<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Arup-->
<!-- * Date: 12/13/2018-->
<!-- * Time: 4:54 PM-->
<!-- */-->
<div class="main_wrapper nc_gallery_section pad_t_b_80">
	<div class="container">
		<div class="row">
			<div class="nc_photo_galley" id="photo_gallery_second">
				<div class="col-md-3">
					<div class ="photo_grid width_2">
						<div class="gallery_cover">
							<a href="#small_dialog2" class="photo_gallery_popup">
								<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg" alt="gallery">
								<div class="gallery_overlay triangle_shape"> </div>
							</a>
							<div id="small_dialog2" class="zoom_anim mfp-hide">
								<div class="gallery_thumb">
									<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg"  alt="gallery">
									<div class="overlay triangle_shape">

									</div>
								</div>
								<div class="gallery_desc">
									<h3>night club party</h3>
									<p>
										There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
									</p>
									<a href="#" class="read_m_btn triangle_btn">read more</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class ="photo_grid width_2">
						<div class="gallery_cover">
							<a href="#small_dialog2" class="photo_gallery_popup">
								<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg" alt="gallery">
								<div class="gallery_overlay triangle_shape"> </div>
							</a>
							<div id="small_dialog2" class="zoom_anim mfp-hide">
								<div class="gallery_thumb">
									<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg"  alt="gallery">
									<div class="overlay triangle_shape">

									</div>
								</div>
								<div class="gallery_desc">
									<h3>night club party</h3>
									<p>
										There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
									</p>
									<a href="#" class="read_m_btn triangle_btn">read more</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class ="photo_grid width_2">
						<div class="gallery_cover">
							<a href="#small_dialog2" class="photo_gallery_popup">
								<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg" alt="gallery">
								<div class="gallery_overlay triangle_shape"> </div>
							</a>
							<div id="small_dialog2" class="zoom_anim mfp-hide">
								<div class="gallery_thumb">
									<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg"  alt="gallery">
									<div class="overlay triangle_shape">

									</div>
								</div>
								<div class="gallery_desc">
									<h3>night club party</h3>
									<p>
										There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
									</p>
									<a href="#" class="read_m_btn triangle_btn">read more</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class ="photo_grid width_2">
						<div class="gallery_cover">
							<a href="#small_dialog2" class="photo_gallery_popup">
								<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg" alt="gallery">
								<div class="gallery_overlay triangle_shape"> </div>
							</a>
							<div id="small_dialog2" class="zoom_anim mfp-hide">
								<div class="gallery_thumb">
									<img src="<?= base_url()?>assets/frontEnd/images/chess_play_bg.jpg"  alt="gallery">
									<div class="overlay triangle_shape">

									</div>
								</div>
								<div class="gallery_desc">
									<h3>night club party</h3>
									<p>
										There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
									</p>
									<a href="#" class="read_m_btn triangle_btn">read more</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


