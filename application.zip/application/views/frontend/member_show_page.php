<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Arup-->
<!-- * Date: 12/13/2018-->
<!-- * Time: 3:35 PM-->
<!-- */-->
<div class="main_wrapper nc_offers_section">
	<div class="container">
		<div class="row">
			<div class="middle_inner nc_offers_main">
				<div class="col-md-12 col-sm-12">
					<aside class="widget nc_recent_post">
						<div class="col-md-3" style="text-align: center; padding: 0 10px;">
							<img src="<?= base_url()?>assets/frontEnd/images/testimonial_1.jpg" alt="Recent blog" />
							<div class="triangle_box" style="color: #fff">
								<p>Lorem Ipsum is simply </p>
								<span >April 17, 2018</span>
							</div>
						</div>

						<div class="col-md-3" style="text-align: center; padding: 0 10px;">
							<img src="<?= base_url()?>assets/frontEnd/images/testimonial_1.jpg" alt="Recent blog" />
							<div class="triangle_box" style="color: #fff">
								<p>Lorem Ipsum is simply </p>
								<span >April 17, 2018</span>
							</div>
						</div>

						<div class="col-md-3" style="text-align: center; padding: 0 10px;">
							<img src="<?= base_url()?>assets/frontEnd/images/testimonial_1.jpg" alt="Recent blog" />
							<div class="triangle_box" style="color: #fff">
								<p>Lorem Ipsum is simply </p>
								<span >April 17, 2018</span>
							</div>
						</div>

						<div class="col-md-3" style="text-align: center; padding: 0 10px;">
							<img src="<?= base_url()?>assets/frontEnd/images/testimonial_1.jpg" alt="Recent blog" />
							<div class="triangle_box" style="color: #fff">
								<p>Lorem Ipsum is simply </p>
								<span >April 17, 2018</span>
							</div>
						</div>

					</aside>
				</div>
			</div>
		</div>
	</div>
</div>
