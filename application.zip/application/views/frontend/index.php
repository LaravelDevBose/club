<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Arup-->
<!-- * Date: 12/11/2018-->
<!-- * Time: 5:44 PM-->
<!-- */-->
<!--  header start -->
<div class="main_wrapper nc_header_main_home1">
	<div class="nc_slider_home">
		<div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classicslider1" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
			<div id="rev_slider_4_1" class="rev_slider fullwidthabanner" data-version="5.0.7">
				<ul>
					<li data-index="rs-1" data-transition="zoomin" data-slotamount="default"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"   data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-description="">
						<img src="<?= base_url()?>assets/frontend/images/pool_bg.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
					</li>
					<li data-index="rs-2" data-transition="zoomin" data-slotamount="default"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"   data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-description="">
						<img src="<?= base_url()?>assets/frontend/images/chess_play_bg.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<?php $this->load->view('frontend/menu');?>
	<div class=" nc_home_2">
		<div class="container">
			<div class="row">

				<div class="col-md-4 col-md-offset-2 about_us">
					<h3>About Club</h3>
					<p>It is a long established fact that a reader will be distracted by the readable. It is a long established fact that a reader will be distracted by the readable.
						It is a long established fact that a reader will be distracted by the readable. It is a long established fact that a reader will be distracted by the readable.
					</p>
				</div>

				<div class="col-md-4 col-md-offset-2 pull-right contact_us">
					<h3>Contact Us</h3>
					<span>
						<i class="fa fa-envelope-o" aria-hidden="true"></i> club@gmail.com
					</span>
					<span>
						<i class="fa fa-phone" aria-hidden="true"></i> club@gmail.com
					</span>
					<span>
						<i class="fa fa-map-marker" aria-hidden="true"></i> club@gmail.com
					</span>
				</div>
			</div> <!-- row -->
			<div class="row">
				<div class="col-sm-6">
					<div class="left_text">
						<p class="footer_text">CopyRight @ 2018 Club 9698.com</p>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="nc_copright_text pull-right">
						<p class="footer_text">Developed By <a href="http://www.linktechbd.com" style="color: #fff"><img style="height: 15px;" src="http://www.linktechbd.com/images/link-up_technology.png" alt="link-up-technology">Link Up Technology</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
