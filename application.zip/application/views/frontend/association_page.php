<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Arup-->
<!-- * Date: 12/13/2018-->
<!-- * Time: 3:06 PM-->
<!-- */-->
<div class="main_wrapper nc_offers_section">
	<div class="container">
		<div class="row">
			<!-- middle heading start-->
<!--			<div class="nc_heading_middle">-->
<!--				<h2> --><?php //if(isset($title)): echo $title; endif; ?><!-- </h2>-->
<!--			</div>-->
			<!-- middle heading end-->
			<div class="middle_inner nc_offers_main">
				<div class="col-md-12 col-sm-12">
					<div class="offers_box_wrapper">
						<embed src="<?= base_url()?>assets/frontEnd/images/pdf-sample.pdf" type="application/pdf" width="100%" height="600px" />
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
