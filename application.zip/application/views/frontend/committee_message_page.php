<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Arup-->
<!-- * Date: 12/13/2018-->
<!-- * Time: 12:43 PM-->
<!-- */-->

<div class="main_wrapper nc_offers_section">
	<div class="container">
		<div class="row">
			<div class="middle_inner nc_offers_main">
				<div class="col-md-12 col-sm-12">
					<div class="offers_box_wrapper">
						<div class="box_thumb">
							<img src="<?= base_url()?>assets/frontEnd/images/testimonial_1.jpg" class="img-reponsive" alt="">
						</div>
						<div class="right_details">
							<h4><a href="#">Drinks All Night</a></h4>
							<p>It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
								It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
								It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
								It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
								It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
								It is a long established fact that a reader will be
								distracted by the readable content of a page when
								looking at its layout. The point of using Lorem
								is that it has a more-or-less normal .
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


