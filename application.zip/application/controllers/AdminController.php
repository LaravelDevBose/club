<?php
/**
 * Created by PhpStorm.
 * User: Arup
 * Date: 12/11/2018
 * Time: 5:36 PM
 */

class AdminController extends MY_Controller
{

}
